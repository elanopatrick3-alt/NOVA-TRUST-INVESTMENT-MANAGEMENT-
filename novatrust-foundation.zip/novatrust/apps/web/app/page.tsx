const products = [
  { title: "Global Equities", text: "Diversified exposure to established and emerging markets." },
  { title: "Managed Portfolios", text: "Professionally structured portfolios built around defined objectives." },
  { title: "Real Assets", text: "Access to carefully selected real-estate and infrastructure opportunities." },
  { title: "Multi-Asset Strategies", text: "Flexible allocations designed to balance opportunity and risk." }
];

export default function HomePage() {
  return (
    <main>
      <header className="site-header">
        <a className="brand" href="/">NovaTrust<span>Investments</span></a>
        <nav>
          <a href="#about">About</a>
          <a href="#investments">Investments</a>
          <a href="#markets">Markets</a>
          <a href="#support">Support</a>
        </nav>
        <div className="header-actions">
          <a className="login" href="/login">Sign in</a>
          <a className="button small" href="/register">Create account</a>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">GLOBAL INVESTMENT SOLUTIONS</p>
          <h1>Build your financial future with clarity.</h1>
          <p className="hero-text">
            A professional digital experience for exploring investments,
            monitoring portfolios, and managing your account in one place.
          </p>
          <div className="hero-actions">
            <a className="button" href="/register">Open an account</a>
            <a className="button secondary" href="#investments">Explore investments</a>
          </div>
          <p className="disclaimer">
            Investments involve risk. Returns are not guaranteed.
          </p>
        </div>
        <div className="hero-card">
          <div className="card-top"><span>Portfolio overview</span><span>•••</span></div>
          <div className="balance">$128,450.72</div>
          <div className="positive">+8.42% <small>illustrative</small></div>
          <div className="chart">
            <span></span><span></span><span></span><span></span><span></span>
            <span></span><span></span><span></span><span></span><span></span>
          </div>
          <div className="chart-labels"><span>JAN</span><span>JUN</span><span>DEC</span></div>
        </div>
      </section>

      <section id="markets" className="ticker">
        <div><strong>Global Markets</strong><span>Equities</span><b>+1.24%</b></div>
        <div><span>FX</span><b>+0.48%</b></div>
        <div><span>Real Assets</span><b>+0.71%</b></div>
        <div><span>Multi-Asset</span><b>+0.93%</b></div>
      </section>

      <section id="about" className="section intro">
        <p className="eyebrow">WHY NOVATRUST</p>
        <h2>Designed around informed decisions.</h2>
        <p>
          NovaTrust brings portfolio visibility, investment discovery, account
          management, and support into a single, straightforward experience.
        </p>
      </section>

      <section id="investments" className="section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">INVESTMENT SOLUTIONS</p>
            <h2>Explore opportunities.</h2>
          </div>
          <a href="/investments">View all</a>
        </div>
        <div className="grid">
          {products.map((product) => (
            <article className="product-card" key={product.title}>
              <div className="icon">N</div>
              <h3>{product.title}</h3>
              <p>{product.text}</p>
              <a href="/investments">Learn more →</a>
            </article>
          ))}
        </div>
      </section>

      <section className="section security">
        <div>
          <p className="eyebrow">SECURITY & TRANSPARENCY</p>
          <h2>Trust should be visible.</h2>
          <p>
            The platform is structured for strong authentication, audit trails,
            document controls, and clear disclosures. Regulatory and licensing
            information will be published only after it has been verified.
          </p>
        </div>
        <div className="security-list">
          <div><b>01</b><span>Account security & verification</span></div>
          <div><b>02</b><span>Transaction and activity records</span></div>
          <div><b>03</b><span>Clear risk disclosures</span></div>
        </div>
      </section>

      <section id="support" className="cta">
        <p className="eyebrow">READY WHEN YOU ARE</p>
        <h2>Start with a clearer view of your investments.</h2>
        <a className="button" href="/register">Create your account</a>
      </section>

      <footer>
        <div className="brand">NovaTrust<span>Investments</span></div>
        <p>© 2026 NovaTrust Investments. All rights reserved.</p>
        <div><a href="#">Privacy</a><a href="#">Terms</a><a href="#">Risk disclosure</a></div>
      </footer>
    </main>
  );
}
