import "../auth.css";

export default function LoginPage() {
  return (
    <main className="auth-page">
      <div className="auth-card">
        <a className="brand" href="/">NovaTrust<span>Investments</span></a>
        <h1>Welcome back</h1>
        <p>Sign in to access your account.</p>
        <form>
          <label>Email address<input type="email" name="email" required /></label>
          <label>Password<input type="password" name="password" required /></label>
          <button className="button" type="submit">Sign in</button>
        </form>
        <a href="/recover">Forgot password or need help?</a>
        <div className="auth-divider">New to NovaTrust?</div>
        <a className="button secondary" href="/register">Create account</a>
      </div>
    </main>
  );
}
