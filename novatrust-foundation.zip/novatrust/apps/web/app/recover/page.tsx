import "../auth.css";

export default function RecoverPage() {
  return (
    <main className="auth-page">
      <div className="auth-card">
        <a className="brand" href="/">NovaTrust<span>Investments</span></a>
        <h1>Recover your account</h1>
        <p>Enter your email or phone number and we’ll guide you through verification.</p>
        <form>
          <label>Email or phone<input type="text" name="identifier" required /></label>
          <button className="button" type="submit">Continue</button>
        </form>
        <p><a href="/login">Back to sign in</a></p>
      </div>
    </main>
  );
}
